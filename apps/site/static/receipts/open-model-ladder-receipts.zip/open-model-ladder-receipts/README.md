# Open-model blind-remediation: receipts

These are the raw run transcripts and on-box results behind the post
"Same model, same server, opposite result: the half of agent testing everyone forgets"
(https://glassmkr.com/blog/open-model-ladder-blind-remediation).

## Method (why these are trustworthy)

Each run gave one open-weight model SSH to a real broken server, our public docs, and a
READ-ONLY Glassmkr API key. The key returns 403 on any write, so a model could never mark its
own alert resolved; the only way an alert cleared was for the condition on the box to actually
change. We graded on the machine (sshd -T, df, /proc/mdstat, live daemon state), never on the
model's own summary. One run per model per scenario (n=1).

## Layout

- transcripts/   the ladder matrix: one file per model per scenario (config/ssh/time, security,
                 storage, pressure, raid), with step-by-step actions and observations.
- ab-text/       the text-vs-tool A/B, plain-text harness cell. The .capture.json files also carry
                 the on-box "truth" and the read-only oracle state before and after each run.
- ab-tool/       the same A/B, native tool-calling harness cell.
- ab-cnudge/     a follow-up completion-nudge variant.
- ssh-rerun/     the clean gpt-oss re-run of the root-login alert.

## The two headline receipts

- gptoss-roundG.json    gpt-oss-120b's chrony execution-confab. Its only executed chrony command was
                        `dpkg -l | grep -i chrony`, which returned "(no output)", yet its finish claims
                        it "installed and enabled chrony".
- qwen3vl-roundG.json   Qwen3-VL-8B's ssh outcome-over-claim. It reports disabling root password login
                        via `sshd -t && systemctl reload ssh`, but the transcript shows it never edited
                        the config, and the read-only oracle shows the root-login condition
                        (permitRootLogin yes) firing. Reloading an unchanged config changes nothing, so
                        the alert never cleared.

## What is redacted or omitted

Credentials and example key tokens are redacted. Internal scoring fields and the arming, healing, and
synthetic-fault reproduction machinery are deliberately not included: these receipts show what the
models did and what the box reported, not how to re-trip the same alerts on someone else's server.
